import type { Meta, StoryObj } from '@storybook/react';
import { IntegrationSelection } from './IntegrationSelection';

const meta = {
  title: 'Screens/IntegrationSelection',
  component: IntegrationSelection,
  parameters: {
    layout: 'fullscreen',
  },
} satisfies Meta<typeof IntegrationSelection>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
