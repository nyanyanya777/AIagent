import type { Meta, StoryObj } from '@storybook/react';
import { AccountSettings } from './AccountSettings';

const meta = {
  title: 'Screens/AccountSettings',
  component: AccountSettings,
  tags: ['autodocs'],
} satisfies Meta<typeof AccountSettings>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
