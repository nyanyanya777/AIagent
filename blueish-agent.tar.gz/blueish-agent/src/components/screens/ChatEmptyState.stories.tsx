import type { Meta, StoryObj } from '@storybook/react';
import { ChatEmptyState } from './ChatEmptyState';

const meta = {
  title: 'Screens/ChatEmptyState',
  component: ChatEmptyState,
  tags: ['autodocs'],
} satisfies Meta<typeof ChatEmptyState>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
