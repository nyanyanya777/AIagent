import type { Meta, StoryObj } from '@storybook/react';
import { RoleSelection } from './RoleSelection';

const meta = {
  title: 'Screens/RoleSelection',
  component: RoleSelection,
  parameters: {
    layout: 'fullscreen',
  },
} satisfies Meta<typeof RoleSelection>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
