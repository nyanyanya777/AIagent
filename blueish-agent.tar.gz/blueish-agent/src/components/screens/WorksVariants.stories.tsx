import type { Meta, StoryObj } from '@storybook/react';
import { WorksContext, WorksOutput } from './WorksVariants';

const meta = {
  title: 'Screens/Works',
  tags: ['autodocs'],
} satisfies Meta<typeof WorksContext>;

export default meta;

export const Context: StoryObj = {
  render: () => <WorksContext />,
};

export const Output: StoryObj = {
  render: () => <WorksOutput />,
};
