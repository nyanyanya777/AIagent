'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export function TaskSelection() {
  return (
    <div className="min-h-screen bg-background p-8">
      <Card className="mx-auto max-w-2xl p-8">
        <h1 className="text-3xl font-bold text-foreground">Screen 4: Task Selection</h1>
        <p className="mt-4 text-muted-foreground">Select tasks to analyze</p>
        <div className="mt-8 space-y-4">
          <Button>Continue</Button>
        </div>
      </Card>
    </div>
  );
}
