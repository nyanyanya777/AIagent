import type { Meta, StoryObj } from '@storybook/react';
import { Analyzing } from './Analyzing';

const meta = {
  title: 'Screens/Analyzing',
  component: Analyzing,
  tags: ['autodocs'],
} satisfies Meta<typeof Analyzing>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
