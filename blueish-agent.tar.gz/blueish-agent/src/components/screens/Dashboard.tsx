import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton } from '@/components/ui/sidebar';
import { i18n } from '@/lib/i18n';

export const Dashboard: React.FC = () => {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar className="w-64 border-r">
        <SidebarHeader>
          <h2 className="text-lg font-semibold">{i18n.agent}</h2>
        </SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton isActive>{i18n.dashboard}</SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton>{i18n.tasks}</SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton>{i18n.settings}</SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarContent>
      </Sidebar>

      <div className="flex-1 flex flex-col">
        <div className="border-b p-4">
          <h1 className="text-2xl font-bold">{i18n.dashboard}</h1>
        </div>

        <div className="flex-1 flex gap-4 p-4 overflow-hidden">
          <div className="flex-1 flex flex-col gap-4">
            <Card className="flex-1 flex flex-col">
              <CardHeader>
                <CardTitle>{i18n.chat}</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col">
                <div className="flex-1 border rounded p-4 mb-4 bg-muted/50">
                  {/* Messages would appear here */}
                </div>
                <div className="flex gap-2">
                  <Input placeholder={i18n.chatPlaceholder} />
                  <Button>{i18n.send}</Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="w-72">
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="text-base">{i18n.tasks}</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Task list would appear here */}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
