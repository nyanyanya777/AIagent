import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const IntegrationSelection: React.FC = () => {
  const integrations = [
    { name: 'Slack', status: 'Available' },
    { name: 'Teams', status: 'Available' },
    { name: 'Gmail', status: 'Available' },
    { name: 'Jira', status: 'Coming Soon' },
  ];

  return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Connect Integrations</CardTitle>
          <CardDescription>Select the tools you want to integrate</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {integrations.map((integration) => (
              <div key={integration.name} className="flex items-center justify-between p-3 border rounded-lg">
                <span className="font-medium">{integration.name}</span>
                <Badge variant={integration.status === 'Available' ? 'default' : 'secondary'}>
                  {integration.status}
                </Badge>
              </div>
            ))}
          </div>
          <div className="flex gap-3 mt-6">
            <Button variant="outline" className="flex-1">Skip</Button>
            <Button className="flex-1">Continue</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default IntegrationSelection;
