'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export function AccountSettings() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-3xl font-bold text-foreground">Screen 13: Account Settings</h1>
        <Card className="mt-8 p-8">
          <form className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground">Account Name</label>
              <input className="mt-1 w-full rounded border border-input bg-background px-3 py-2" />
            </div>
            <Button>Save Changes</Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
