import type { Meta, StoryObj } from '@storybook/react';
import { TaskSelection } from './TaskSelection';

const meta = {
  title: 'Screens/TaskSelection',
  component: TaskSelection,
  tags: ['autodocs'],
} satisfies Meta<typeof TaskSelection>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
