'use client';

import { Progress } from '@/components/ui/progress';
import { Card } from '@/components/ui/card';

export function Analyzing() {
  return (
    <div className="min-h-screen bg-background p-8">
      <Card className="mx-auto max-w-2xl p-8">
        <h1 className="text-3xl font-bold text-foreground">Screen 5: Analyzing</h1>
        <p className="mt-4 text-muted-foreground">Analyzing your integration...</p>
        <div className="mt-8">
          <Progress value={65} />
        </div>
      </Card>
    </div>
  );
}
