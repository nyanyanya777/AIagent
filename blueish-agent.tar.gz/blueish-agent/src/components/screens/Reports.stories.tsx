import type { Meta, StoryObj } from '@storybook/react';
import { Reports } from './Reports';

const meta = {
  title: 'Screens/Reports',
  component: Reports,
  tags: ['autodocs'],
} satisfies Meta<typeof Reports>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
