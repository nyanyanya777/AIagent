import type { Meta, StoryObj } from '@storybook/react';
import { PermissionAlert, PermissionConfirm } from './Permission';

const meta = {
  title: 'Screens/Permission',
  tags: ['autodocs'],
} satisfies Meta<typeof PermissionAlert>;

export default meta;

export const Alert: StoryObj = {
  render: () => <PermissionAlert />,
};

export const Confirm: StoryObj = {
  render: () => <PermissionConfirm />,
};
