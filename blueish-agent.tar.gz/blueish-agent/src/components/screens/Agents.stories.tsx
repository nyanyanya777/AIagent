import type { Meta, StoryObj } from '@storybook/react';
import { Agents } from './Agents';

const meta = {
  title: 'Screens/Agents',
  component: Agents,
  tags: ['autodocs'],
} satisfies Meta<typeof Agents>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
