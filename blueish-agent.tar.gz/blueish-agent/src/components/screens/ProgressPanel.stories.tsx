import type { Meta, StoryObj } from '@storybook/react';
import { ProgressPanelEmpty, ProgressPanelPopulated } from './ProgressPanel';

const meta = {
  title: 'Screens/ProgressPanel',
  tags: ['autodocs'],
} satisfies Meta<typeof ProgressPanelEmpty>;

export default meta;

export const Empty: StoryObj = {
  render: () => <ProgressPanelEmpty />,
};

export const Populated: StoryObj = {
  render: () => <ProgressPanelPopulated />,
};
