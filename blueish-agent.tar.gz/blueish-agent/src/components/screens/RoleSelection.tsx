import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export const RoleSelection: React.FC = () => {
  const roles = ['Administrator', 'Manager', 'Developer', 'Analyst'];

  return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Select Your Role</CardTitle>
          <CardDescription>Choose the role that best describes your position</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {roles.map((role) => (
              <Button key={role} variant="outline" className="h-auto py-4 flex flex-col">
                <span className="text-lg font-semibold">{role}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RoleSelection;
