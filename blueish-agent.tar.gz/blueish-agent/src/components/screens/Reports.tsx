'use client';

import { Card } from '@/components/ui/card';

export function Reports() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-4xl">
        <h1 className="text-3xl font-bold text-foreground">Screen 11: Reports</h1>
        <p className="mt-4 text-muted-foreground">View your reports</p>
        <div className="mt-8">
          <Card className="p-4">
            <p className="text-center text-muted-foreground">No reports available</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
