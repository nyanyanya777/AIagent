import type { Meta, StoryObj } from '@storybook/react';
import { ConnectionSettings } from './ConnectionSettings';

const meta = {
  title: 'Screens/ConnectionSettings',
  component: ConnectionSettings,
  tags: ['autodocs'],
} satisfies Meta<typeof ConnectionSettings>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
