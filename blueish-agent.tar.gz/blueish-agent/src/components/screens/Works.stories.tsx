import type { Meta, StoryObj } from '@storybook/react';
import { Works } from './Works';

const meta = {
  title: 'Screens/Works',
  component: Works,
  tags: ['autodocs'],
} satisfies Meta<typeof Works>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
