import type { Meta, StoryObj } from '@storybook/react';
import { DashboardEmptyState } from './DashboardEmptyState';

const meta = {
  title: 'Screens/DashboardEmptyState',
  component: DashboardEmptyState,
  tags: ['autodocs'],
} satisfies Meta<typeof DashboardEmptyState>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
