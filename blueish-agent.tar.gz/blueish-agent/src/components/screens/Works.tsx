'use client';

import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function Works() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-4xl">
        <h1 className="text-3xl font-bold text-foreground">Screen 8: Works</h1>
        <div className="mt-8 grid gap-4">
          <Card className="p-4">
            <h2 className="font-semibold text-foreground">Integration Status</h2>
            <Badge className="mt-2">Connected</Badge>
          </Card>
        </div>
      </div>
    </div>
  );
}
