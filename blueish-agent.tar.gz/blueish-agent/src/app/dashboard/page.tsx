'use client';

import Link from 'next/link';
import { Dashboard } from '@/components/screens/Dashboard';

export default function DashboardPage() {
  return (
    <div>
      <div className="mb-4 p-4 bg-gray-100">
        <Link href="/" className="text-blue-600 hover:text-blue-800 underline">
          ← Back to Home
        </Link>
      </div>
      <Dashboard />
    </div>
  );
}
