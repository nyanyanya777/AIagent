import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-5xl font-bold text-blue-900 mb-4">Blueish Agent</h1>
        <p className="text-xl text-gray-700 mb-8">Welcome to the Blueish Agent dashboard application.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
          <Link 
            href="/dashboard"
            className="p-8 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow border-2 border-blue-500"
          >
            <h2 className="text-2xl font-bold text-blue-900 mb-2">Dashboard</h2>
            <p className="text-gray-600">View the main dashboard with agent monitoring and controls.</p>
          </Link>
          
          <Link 
            href="/storybook/index.html"
            className="p-8 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow border-2 border-purple-500"
          >
            <h2 className="text-2xl font-bold text-purple-900 mb-2">Storybook</h2>
            <p className="text-gray-600">Explore component library and interactive UI documentation.</p>
          </Link>
        </div>
        
        <div className="mt-12 p-6 bg-blue-100 rounded-lg">
          <p className="text-gray-700">
            This application is protected with basic authentication. Use your credentials to access all features.
          </p>
        </div>
      </div>
    </main>
  );
}
